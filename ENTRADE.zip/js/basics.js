const isMobile = /Mobi|Android/i.test(navigator.userAgent) || window.innerWidth < 850 || /Mobi|Android/i.test(navigator.userAgent) && (window.innerWidth < window.innerHeight);


const message = (/The ENTRADE tool is down since:     (.*)/);

	function getOrientation() {
		if(screen.height > screen.width){	    
			return "portrait";
		} else {
			return "landscape";
		} 
	}


// read variables from URL
// code from http://papermashup.com/read-url-get-variables-withjavascript/
function getUrlVars() {
	const vars = {};
	window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, (m, key, value) => {
		vars[key] = value;
	});
	return vars;
};

// HTML escape helper to prevent XSS / reflected content
function escapeHTML(str) {
	if (str === null || str === undefined) return '';
	return String(str)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');
}

// Shared helper to build top 5 series + Others bucket for charts
function buildTop5Series(data, otherLabel) {
	const resolvedOther = otherLabel || (languageNameSpace && languageNameSpace.labels && languageNameSpace.labels["OTH"]) || "Others";
	const sorted = [...data].sort((a, b) => b.y - a.y);
	if (REF.filter !== "top5") {
		return sorted;
	}
	const top5 = sorted.slice(0, 5);
	const sumOfOthers = sorted.slice(5).reduce((sum, item) => sum + item.y, 0);
	if (sumOfOthers > 0) {
		top5.push({ name: resolvedOther, y: sumOfOthers });
	}
	return top5;
}

// change URL by adding new item to history
// code from http://www.aspsnippets.com/Articles/Change-Browser-URL-without-reloading-refreshing-page-using-HTML5-in-JavaScript-and-jQuery.aspx
function changeUrl(title, url) {
	if (typeof (history.pushState) != "undefined") {
		const obj = {
			Title: title,
			Url: url
		};
		history.pushState(obj, obj.Title, obj.Url);
	} else {
		console.error(languageNameSpace.labels["MSG_BROWSER"]);
	};
};




const excludedPartners = ["AFR_OTH", "AME_OTH", "ASI_NME_OTH", "ASI_OTH", "EUR_OTH", "EX_SU_OTH", "NSP", "TOTAL"];

	function addChartOptions() {
		const chartOptions = new ChartControls();
		chartOptions.addToDOM("#subnavbar-container"); 
  	}

	  function removeChartOptions() {
		const chartOptions = new ChartControls();
		chartOptions.removeFromDOM(); 

		const mapcontainer = document.querySelector("#map");
    
		if (mapcontainer) {
		  mapcontainer.style.width = "100%";
		  mapcontainer.style.display = "block";
		} else {
			console.error("Map element not found.");
		}
	
		const chartContainerEl = document.getElementById('chartContainer');
		if (chartContainerEl) {
		  chartContainerEl.style.display = 'none';
		  chartContainerEl.innerHTML = '';
		  if (typeof resetChartContainerPosition === 'function') resetChartContainerPosition();
		}

		// Reset flag so openFactSheet can be triggered again
		isOpenChartContainer = false;

		// Re-add the factSheet button if a country is still selected (has drawn flow lines)
		if (typeof mapCenterCoords !== 'undefined' && mapCenterCoords) {
		  // Remove stale countryInfo if present, then re-insert
		  const existingInfo = document.getElementById('countryInfo');
		  if (existingInfo) existingInfo.remove();
		  countryInfo(mapCenterCoords);
		}
	  }

/* Chart loader (small ECL spinner overlay) */
function showChartLoader(message = '') {
  const container = document.getElementById('chartContainer');
  if (!container) return;
  // ensure the container is visible while loading
  container.style.display = 'block';
  // prevent duplicate
  if (container.querySelector('.chart-loader-wrapper')) return;
  const wrapper = document.createElement('div');
  wrapper.className = 'chart-loader-wrapper';
  wrapper.innerHTML = `
    <div class="ecl-spinner ecl-spinner--visible ecl-spinner--small ecl-spinner--centered" role="status" aria-live="polite">
      <span class="ecl-spinner__loader" aria-hidden="true"></span>
      ${message ? `<span class="ecl-spinner__text">${message}</span>` : ''}
    </div>
  `;
  container.appendChild(wrapper);
}

function hideChartLoader() {
  const container = document.getElementById('chartContainer');
  if (!container) return;
  const wrapper = container.querySelector('.chart-loader-wrapper');
  if (wrapper) wrapper.remove();
}

// Show a small, accessible transient popup used across map/chart/table when a dataset contains only zeros
function showNoDataPopup(message = languageNameSpace.labels['NODATA'], duration = 3000) {
  if (!message) message = 'No data available';
  // avoid duplicates
  if (document.querySelector('.alert-popup')) return;

  // role="alert" triggers an assertive live-region announcement so screen readers
  // immediately read the message without waiting for a natural pause (role="status"
  // uses polite/"wait", which is too passive for a "no data" error state).
  const content = /*html*/ `
    <div class="alert-popup" role="alert">
      <div style="display: flex; align-items: center; margin-right: 16px;">
        <i class="fas fa-exclamation-triangle" style="color: #ffcc00; margin-right: 8px;" aria-hidden="true"></i>
        <p style="display: inline-block; margin: 0;">${message}</p>
      </div>
      <div>
        <button type="button" class="ecl-button ecl-button--secondary close-alert-btn" id="closeAlertPopup" aria-label="Close notification">
          <i class="fas fa-times" aria-hidden="true"></i>
        </button>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', content);

  // Save the element that triggered the popup so focus can be restored after dismissal.
  const previouslyFocused = document.activeElement;

  const removeAlertPopup = () => {
    const popup = document.querySelector('.alert-popup');
    if (popup) popup.remove();
    // Return focus so keyboard users don't lose their position in the page.
    if (previouslyFocused && typeof previouslyFocused.focus === 'function') {
      previouslyFocused.focus();
    }
  };

  // auto-dismiss
  const timer = setTimeout(removeAlertPopup, duration);

  const closeBtn = document.querySelector('#closeAlertPopup');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      clearTimeout(timer);
      removeAlertPopup();
    });
    // Move focus to the close button so keyboard users can dismiss it immediately.
    closeBtn.focus();
  }
}

// Insert a visible, accessible "no data" message inside the main chart container (visual fallback)
function showNoDataInChartContainer(message = languageNameSpace.labels['NODATA']) {
  const container = document.getElementById('chartContainer');
  if (!container) return;
  container.innerHTML = '';
  const titleEl = document.createElement('h2');
  titleEl.className = 'chartTitle';
  titleEl.textContent = getTitle();

  const msg = document.createElement('div');
  msg.className = 'no-data-message';
  msg.setAttribute('role', 'status');
  msg.setAttribute('aria-live', 'polite');
  msg.textContent = message || languageNameSpace.labels['NODATA'];

  container.appendChild(titleEl);
  container.appendChild(msg);
}

		function openDataset() {
			window.open(" https://ec.europa.eu/eurostat/databrowser/view/"+ REF.dataset +"/default/table?lang="+ REF.language, "_self");	
		}

		function openMetadata () {
			window.open("https://ec.europa.eu/eurostat/cache/metadata/en/nrg_t_esms.htm", "_self");
		}
		function openContact () {
			document.location = "mailto:ESTAT-ENERGY@ec.europa.eu?subject=ENERGY%20TRADE%20CONTACT&body="+encodeURIComponent(window.location.href);
		}




		function getHighchartInstance(containerId = "chartContainer") {
		  const container = typeof containerId === "string" ? document.getElementById(containerId) : containerId;
		  if (!container) return null;

		  if (typeof container.highcharts === "function") {
		    return container.highcharts();
		  }

		  const chartIndex = container.getAttribute && container.getAttribute("data-highcharts-chart");
		  if (chartIndex !== null && chartIndex !== undefined && window.Highcharts && window.Highcharts.charts && window.Highcharts.charts[chartIndex]) {
		    return window.Highcharts.charts[chartIndex];
		  }

		  if (window.Highcharts && Array.isArray(window.Highcharts.charts)) {
		    const match = window.Highcharts.charts.find(chart => chart && chart.renderTo && (chart.renderTo === container || chart.renderTo.id === containerId));
		    if (match) return match;

		    const activeCharts = window.Highcharts.charts.filter(c => c && c.renderTo && document.body.contains(c.container));
		    if (activeCharts.length > 0) {
		      return activeCharts[activeCharts.length - 1];
		    }
		  }

		  return null;
		}

		function printChart() { 
		  const chart = getHighchartInstance();
		  if (chart && typeof chart.print === 'function') {
		    chart.print();
		  }
		}
		
		function fallbackSvgDownload(svgString, filename) {
		  const svgFilename = filename.replace(/\.png$/i, '.svg');
		  const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
		  const url = URL.createObjectURL(blob);
		  const a = document.createElement('a');
		  a.href = url;
		  a.download = svgFilename;
		  document.body.appendChild(a);
		  a.click();
		  document.body.removeChild(a);
		  setTimeout(() => URL.revokeObjectURL(url), 2000);
		}

		async function exportPngChart() { 
		  const chart = getHighchartInstance();
		  if (!chart) return;

		  const filename = (chart.getFilename ? chart.getFilename() : 'chart') + '.png';
		  const exportOptions = {
		    sourceWidth: 1200,
		    sourceHeight: 850
		  };

		  try {
		    let svgString = chart.getSVG ? chart.getSVG(exportOptions) : null;
		    if (!svgString) {
		      const container = chart.container || document.getElementById('chartContainer');
		      const svgEl = container ? container.querySelector('svg') : null;
		      if (svgEl) {
		        svgString = new XMLSerializer().serializeToString(svgEl);
		      }
		    }

		    if (!svgString) {
		      if (typeof chart.exportChart === 'function') {
		        chart.exportChart({ type: 'image/png' });
		      }
		      return;
		    }

		    let cleanSvg = svgString.replace(/href="([^"]+)"/gi, (match, src) => {
		      if (src.startsWith('data:') || src.startsWith('http://') || src.startsWith('https://')) {
		        return match;
		      }
		      try {
		        return `href="${new URL(src, window.location.href).href}"`;
		      } catch (e) {
		        return match;
		      }
		    });

		    if (!cleanSvg.includes('xmlns=')) {
		      cleanSvg = cleanSvg.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"');
		    }

		    const width = 1200;
		    const height = 850;

		    const svgBlob = new Blob([cleanSvg], { type: 'image/svg+xml;charset=utf-8' });
		    const url = URL.createObjectURL(svgBlob);
		    const img = new Image();

		    img.onload = function() {
		      try {
		        const canvas = document.createElement('canvas');
		        canvas.width = width * 2;
		        canvas.height = height * 2;
		        const ctx = canvas.getContext('2d');
		        ctx.fillStyle = '#ffffff';
		        ctx.fillRect(0, 0, canvas.width, canvas.height);
		        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
		        URL.revokeObjectURL(url);

		        if (canvas.toBlob) {
		          canvas.toBlob(function(blob) {
		            if (!blob) {
		              fallbackSvgDownload(svgString, filename);
		              return;
		            }
		            const pngUrl = URL.createObjectURL(blob);
		            const a = document.createElement('a');
		            a.href = pngUrl;
		            a.download = filename;
		            document.body.appendChild(a);
		            a.click();
		            document.body.removeChild(a);
		            setTimeout(() => URL.revokeObjectURL(pngUrl), 2000);
		          }, 'image/png');
		        } else {
		          fallbackSvgDownload(svgString, filename);
		        }
		      } catch (e) {
		        console.warn("Canvas export failed, downloading SVG:", e);
		        fallbackSvgDownload(svgString, filename);
		      }
		    };

		    img.onerror = function(err) {
		      console.warn("Image conversion failed, downloading SVG:", err);
		      URL.revokeObjectURL(url);
		      fallbackSvgDownload(svgString, filename);
		    };

		    img.src = url;
		  } catch (err) {
		    console.error("exportPngChart error:", err);
		    if (typeof chart.exportChart === 'function') {
		      chart.exportChart({ type: 'image/png' });
		    }
		  }
		}
		
		async function exportJpegChart() { 
		  const chart = getHighchartInstance();
		  if (chart && typeof chart.exportChart === 'function') {
		    await chart.exportChart({type: 'image/jpeg'});
		  }
		}
		
		async function exportPdfChart() { 
		  const chart = getHighchartInstance();
		  if (chart && typeof chart.exportChart === 'function') {
		    await chart.exportChart({type: 'application/pdf'});
		  }
		}
		
		async function exportSvgChart() { 
		  const chart = getHighchartInstance();
		  if (chart && typeof chart.exportChart === 'function') {
		    await chart.exportChart({type: 'image/svg+xml'});
		  }
		}
		
		function exportXlsChart() { 
		  const chart = getHighchartInstance();
		  if (!chart) return;
		  if (typeof chart.downloadXLS === 'function') {
		    chart.downloadXLS();
		  } else if (typeof chart.getCSV === 'function') {
		    const csv = chart.getCSV(true);
		    const blob = new Blob(["\uFEFF" + csv], { type: 'application/vnd.ms-excel;charset=utf-8;' });
		    const url = URL.createObjectURL(blob);
		    const a = document.createElement('a');
		    a.href = url;
		    a.download = (chart.getFilename ? chart.getFilename() : 'chart') + '.xls';
		    document.body.appendChild(a);
		    a.click();
		    document.body.removeChild(a);
		  }
		}
		
		function exportCsvChart() { 
		  const chart = getHighchartInstance();
		  if (!chart) return;
		  if (typeof chart.downloadCSV === 'function') {
		    chart.downloadCSV();
		  } else if (typeof chart.getCSV === 'function') {
		    const csv = chart.getCSV(true);
		    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
		    const url = URL.createObjectURL(blob);
		    const a = document.createElement('a');
		    a.href = url;
		    a.download = (chart.getFilename ? chart.getFilename() : 'chart') + '.csv';
		    document.body.appendChild(a);
		    a.click();
		    document.body.removeChild(a);
		  }
		}

		
		
		function mailContact() {
		  document.location = "mailto:ESTAT-ENERGY@ec.europa.eu?subject=ENERGY%20PRICES%20CONTACT&body=" +
		  encodeURIComponent(window.location.href);
		}
		
		function exportTable() {
		  const table = document.querySelector('.highcharts-data-table');
		  if (table) {
		    window.open('data:application/vnd.ms-excel,' + encodeURIComponent(table.innerHTML));
		  }
		}











  function agregateIcon() {
	const iconHTML = `
	<span class="agregates fa-stack fa-rotate-180" style=" position: absolute; top: 8px;">
	  <i class="fa fa-square fa-stack-1x" style="top: .0em; left: .0em; color: white;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .2em; left: .2em; color: #0a328e;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .2em; left: .2em; color: transparent;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .3em; left: .3em; color: white;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .5em; left: .5em; color: #0a328e;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .5em; left: .5em; color: transparent;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .6em; left: .6em; color: white;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .8em; left: .8em; color: #0a328e;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .8em; left: .8em; color: transparent;"></i>
	  <i class="fa fa-square fa-stack-1x" style="top: .9em; left: .9em; color: white;"></i>
	</span>
  `;
  return iconHTML;
  }
  
  function nonagregateIcon() {
	const iconHTML = `
		<span class="nonAgregates fa-stack fa-rotate-180" style="position: absolute;top: 4px;">
		  <i class="fa fa-square fa-stack-1x" style="top: .0em;left: .0em;color: white;"></i>
		  <i class="fa fa-square fa-stack-1x" style="top: .2em;left: .2em;color: #0a328e;"></i>
		  <i class="fa fa-square fa-stack-1x" style="top: .2em;left: .2em;color: transparent;"></i>
		  <i class="fa fa-square fa-stack-1x" style="top: .3em;left: .3em;color: white;"></i>
		</span>`;
  return iconHTML;
  }


  function getTitle() {
	const geoLabel = escapeHTML(languageNameSpace.labels[REF.geo] || REF.geo);
	const time = escapeHTML(REF.year);
	const dataset = escapeHTML(languageNameSpace.labels[REF.dataset] || REF.dataset);
	const unit = escapeHTML(languageNameSpace.labels[REF.unit] || REF.unit);
	const unitAbbr = escapeHTML(languageNameSpace.labels['abr_' + REF.unit] || REF.unit);
	const siecLabel = escapeHTML(languageNameSpace.labels[REF.siec] || REF.siec);
	const depTitle = escapeHTML(languageNameSpace.labels["DEPTITLE"] || "");

	let title = "";
	let subtitle = "";
  
	let chartTitle = "";
	switch (REF.chart) {
	  case "lineChart":
		chartTitle = `${dataset} <br> ${unit} - ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";
		break;
	  case "pieChart":
		chartTitle = `${dataset} <br> ${unit} - ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";
		break;
	  case "depChart":
		chartTitle = `${depTitle} ${siecLabel} - ${time}`;
		title = `${depTitle} ${siecLabel} - ${time}`;
		subtitle = "";
		break;
	  case "barChart":
		chartTitle = `${dataset} <br> ${unit} - ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";
		break;
	  case "tableChart":
		chartTitle = `${geoLabel}, ${dataset} (${unitAbbr}), ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";
		break;
	  case "insightsChart":
		chartTitle = `${geoLabel}, ${dataset} (${unitAbbr}), ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";
		break;
	  default:    	 	 
		chartTitle = `<strong>${geoLabel}</strong>, ${dataset} (${unitAbbr}), ${time}`;
		title = `${dataset} - ${geoLabel} ${time}`;
		subtitle = "";   
	}
  
	const titleElement = document.getElementById("title");
	if (titleElement && REF.geo) {
	  titleElement.innerHTML = title;
	}
	
	const subtitleElement = document.getElementById("subtitle");
	if (subtitleElement) {
	  subtitleElement.innerHTML = subtitle;
	}
  
	return chartTitle;
  }

  function enableScreenREader(params) {
	const titleElement = document.querySelector("text.highcharts-title");
	if (titleElement) {
	  titleElement.setAttribute('aria-hidden', 'false');
	}

	// Find and update the subtitle element
	const subtitleElement = document.querySelector('text.highcharts-subtitle');
	if (subtitleElement) {
	  subtitleElement.setAttribute('aria-hidden', 'false');
	}

	const container = document.querySelector(".highcharts-root");
	if (container) container.removeAttribute('aria-hidden');

	// Ensure Highcharts credits are keyboard-accessible (tab / Enter / Space)
	try {
	  const creditsEl = document.querySelector('.highcharts-credits');
	  if (creditsEl) {
        // prefer making the SVG text focusable in all browsers
        creditsEl.setAttribute('tabindex', '0');
        creditsEl.setAttribute('focusable', 'true');
        creditsEl.setAttribute('role', 'link');

        // remove tabindex from inner <tspan id="credits"> (browsers commonly ignore tabindex on <tspan>)
        const innerTspan = creditsEl.querySelector('tspan#credits');
        if (innerTspan && innerTspan.hasAttribute('tabindex')) innerTspan.removeAttribute('tabindex');

        // set aria-label using available translations (fallbacks)
        const sourceLabel = (window.languageNameSpace && languageNameSpace.labels && languageNameSpace.labels['EXPORT_FOOTER_TITLE']) || 'Source: Eurostat';
        const accessLabel = (window.languageNameSpace && languageNameSpace.labels && (languageNameSpace.labels.DB || languageNameSpace.labels['DB_LINK'])) || 'Access to dataset';
        creditsEl.setAttribute('aria-label', `${sourceLabel} - ${accessLabel}`);

        // ensure visible pointer cursor
        creditsEl.style.cursor = 'pointer';

        // attach key handler to open the dataset URL in a new tab (preferred)
        const datasetURL = (typeof REF !== 'undefined' && REF.dataset)
          ? `https://ec.europa.eu/eurostat/databrowser/view/${REF.dataset}/default/table?lang=${REF.language || 'EN'}`
          : null;

        // ensure anchor (if any) inside credits is focusable
        const anchorInside = creditsEl.querySelector('a');
        if (anchorInside) {
          anchorInside.setAttribute('tabindex', '0');
          anchorInside.setAttribute('role', 'link');
          anchorInside.setAttribute('aria-label', `${sourceLabel} - ${accessLabel}`);
        }

        if (!creditsEl._keyboardHandlerInstalled) {
          creditsEl.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' || ev.key === ' ' || ev.keyCode === 13 || ev.keyCode === 32) {
              ev.preventDefault();
              if (datasetURL) window.open(datasetURL, '_blank');
              else creditsEl.click();
            }
          });

          // prefer opening in new tab on click as well
          creditsEl.addEventListener('click', () => {
            if (datasetURL) window.open(datasetURL, '_blank');
          });

          creditsEl._keyboardHandlerInstalled = true;
        }

        // re-apply after a short delay in case Highcharts redraw replaces the node
        setTimeout(() => {
          const again = document.querySelector('.highcharts-credits');
          if (again) {
            again.setAttribute('tabindex', '0');
            again.setAttribute('focusable', 'true');
          }
        }, 250);

      // ---------------------------------------
      // Accessible credits overlay (HTML <a>)
      // Append to the OUTER chart container (#chartContainer) so it remains in the
      // accessibility tree and tabbable. This is a reliable fallback for SVG text.
      // ---------------------------------------
      setTimeout(() => {
        const chartContainer = document.querySelector('#chartContainer');
        if (!chartContainer) return;

        // Remove existing accessible credits overlay if any
        const prev = chartContainer.querySelector('.accessible-credits-overlay');
        if (prev) prev.remove();

        // Build URL
        const url = (typeof REF !== 'undefined' && REF.dataset)
          ? `https://ec.europa.eu/eurostat/databrowser/view/${REF.dataset}/default/table?lang=${REF.language || 'EN'}`
          : '#';

        const sourceLabel = (window.languageNameSpace && languageNameSpace.labels && languageNameSpace.labels['EXPORT_FOOTER_TITLE']) || 'Source: Eurostat';
        const linkLabel = (window.languageNameSpace && languageNameSpace.labels && (languageNameSpace.labels.DB || languageNameSpace.labels['DB_LINK'])) || 'Access to dataset';

        // Wrapper
        const wrapper = document.createElement('div');
        wrapper.className = 'accessible-credits-overlay';
        wrapper.setAttribute('aria-hidden', 'false');

        // Styling (inline to avoid needing a CSS change deployment)
        Object.assign(wrapper.style, {
          position: 'absolute',
          bottom: '8px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: '12',
          fontFamily: 'arial, sans-serif',
          fontSize: '0.9rem',
          lineHeight: '1',
          color: '#666666',
          whiteSpace: 'nowrap',
          background: 'transparent',
          pointerEvents: 'auto'
        });

        const prefix = document.createElement('span');
        prefix.textContent = `${sourceLabel} - `;

        const a = document.createElement('a');
        a.href = url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.setAttribute('aria-label', `${linkLabel}: ${url}`);
        a.textContent = linkLabel;
        Object.assign(a.style, {
          color: '#0a328e',
          textDecoration: 'underline',
          cursor: 'pointer',
          outline: 'none'
        });

        a.addEventListener('focus', () => { a.style.outline = '2px solid #005ea2'; a.style.outlineOffset = '2px'; });
        a.addEventListener('blur', () => { a.style.outline = 'none'; });

        wrapper.appendChild(prefix);
        wrapper.appendChild(a);

        // Ensure the outer container is positioned so absolute works
        if (getComputedStyle(chartContainer).position === 'static') {
          chartContainer.style.position = 'relative';
        }

        chartContainer.appendChild(wrapper);

        // Hide the original Highcharts SVG credits (prevent duplicate UI)
        const svgCredits = chartContainer.querySelector('.highcharts-credits');
        if (svgCredits) {
          svgCredits.setAttribute('aria-hidden', 'true');
          svgCredits.style.display = 'none';
          svgCredits.style.pointerEvents = 'none';
          svgCredits.removeAttribute('tabindex');
          svgCredits.dataset.hiddenByOverlay = 'true';
        }

        // Observe chartContainer for reinsertion of Highcharts credits and hide them
        if (!chartContainer._creditsHideObserver) {
          const obs = new MutationObserver((mutations) => {
            for (const m of mutations) {
              if (!m.addedNodes) continue;
              m.addedNodes.forEach(node => {
                try {
                  if (!(node instanceof Element)) return;
                  if (node.matches('.highcharts-credits')) {
                    node.setAttribute('aria-hidden', 'true');
                    node.style.display = 'none';
                    node.style.pointerEvents = 'none';
                  } else {
                    const nested = node.querySelector && node.querySelector('.highcharts-credits');
                    if (nested) {
                      nested.setAttribute('aria-hidden', 'true');
                      nested.style.display = 'none';
                      nested.style.pointerEvents = 'none';
                    }
                  }
                } catch (e) {
                  /* ignore */
                }
              });
            }
          });
          obs.observe(chartContainer, { childList: true, subtree: true });
          chartContainer._creditsHideObserver = obs;
        }
      }, 500);
    }
	} catch (e) {
	  // non-fatal; leave original behaviour
	  console.warn('enableScreenREader: credits accessibility patch failed', e);
	}
  }

  function chartNormalTooltip(points) {
	const value = Highcharts.numberFormat(points[0].y, 4);
	const unit = `${languageNameSpace.labels["S_" + REF.currency]}/${languageNameSpace.labels["S_" + REF.unit]}`;
	const na = languageNameSpace.labels['FLAG_NA'];
	const title = REF.chartId==="lineChart" ?  points[0].key : points[0].x
	return this.y == 0 ? `<b>${title}<br>Total: <b>${na}</b>` : `<b>${title}<br>Total: <b>${value}</b> ${unit}`;
  }

  function pieTolltip(point) {
	// Assuming there is a variable 'unit' representing the unit you want to display
	const unit = REF.unit; // Replace 'your_unit' with the actual unit
	const na = languageNameSpace.labels['FLAG_NA'];
  
	const total = point.series.data.reduce((acc, point) => acc + point.y, 0);
	const percentage = (point.options.y / total) * 100;
	const formattedPercentage = Highcharts.numberFormat(percentage, 1);
	const formattedValue = Highcharts.numberFormat(point.y, 0, '', ' ');
  
	const formatPointTooltip = function () {
	  return `
	  <tr class="tooltipTableRow">
		<td><span style="color:${point.color}">\u25CF</span> ${formattedValue}</td>
		<td> ${unit}</td>
	  </tr>
	  <tr class="tooltipTableRow">
		<td><span style="color:${point.color}">\u25CF</span> ${formattedPercentage}</td>
		<td> %</td>
	  </tr>
	  `;
	};
  
	// Construct the complete tooltip content
	const tooltipRows = formatPointTooltip();
  
	// Create the HTML table structure
	const html = `<table id="tooltipTable" class="table_component"> 
	  <thead class="">
		<tr class="">
		  <th scope="col" colspan="2">${point.name}</th>                
		</tr>
	  </thead>
	  <tbody>
		${tooltipRows}
	  </tbody>
	</table>`;
  
	return html;   
  }
  
  function tooltipTable(points) {
	const dec = 0
  
	if(REF.percentage == 1 ){
	  let html = "";
	  html += `<table id="tooltipTable" class="table_component">                
				  <thead>
					<tr>
					  <th scope="cols">${points[0].x}</th>                    
					  <th scope="cols"></th>                    
					</tr>
				  </thead>`
		points.forEach(element => {
			const value = element.point.percentage.toFixed(0); // Limit decimals to three places
			const category = element.point.series.name; 
			const color = element.point.color;              
			html += `<tr>
						<td><svg width="10" height="10" style="vertical-align: baseline;"><circle cx="5" cy="5" r="3" fill="${color}" /></svg> ${category}</td>
						<td>${value} %</td>
					</tr>` 
		});
	  html += `</table>`;
	  return `<div>${html}</div>`;
	} else {
	  let html = "";
	  let totalAdded = false; // Flag to track if the total row has been added
	  let totalColor = "rgb(14, 71, 203)";
  
	  
	  // Sort the points so that the "Total" item is at the last place
	  const sortedPoints = points.sort(function (a, b) {
		if (a.series.name == languageNameSpace.labels['TOTAL']) return 1;
		if (b.series.name == languageNameSpace.labels['TOTAL']) return -1;
		return 0;
	  });
	  
	  html += `<table id="tooltipTable" class="table_component">                
		<thead>
		  <tr>
			<th scope="cols">${sortedPoints[0].key}</th>                    
			<th class="tooltipUnit" scope="cols">${REF.unit}</th>                    
		  </tr>
		</thead>`;
	  
	  sortedPoints.forEach(function (point) {
		const color = point.series.color;
		const value = point.y.toFixed(dec); // Limit decimals to three places
		const category = point.series.name;    
  
		if(REF.details != 0) {
		  html += `<tr>
		  <td><svg width="10" height="10" style="vertical-align: baseline;"><circle cx="5" cy="5" r="3" fill="${color}" /></svg> ${category}</td>
		  <td>${value}</td>
		</tr>`;
		}    
		// Check if point is "Total" and set the flag if found
		if (category == languageNameSpace.labels['total']) {
		  totalAdded = true;
		}
	  });
	  
	  // Check if all values are zero and display a message if they are
	  const allValuesZero = sortedPoints.every(function (point) {
		return point.y === 0;
	  });
	 
	  if (allValuesZero) {
		html = 
	  `<table id="tooltipTable" class="table_component">                
	  <thead>
		<tr>
		  <th scope="cols">${sortedPoints[0].key}</th>                                    
		</tr>
	  </thead><tr>      
	  <td>${languageNameSpace.labels["FLAG_NA"]}</td>
	</tr></table>`;
  
  
	  } else {
		// Add a row for the total if not already added
		if (!totalAdded) {
		  // Calculate the total sum of all values
		  const totalSum = sortedPoints.reduce(function (sum, point) {
			return sum + point.y;
		  }, 0);
	  
		  // Format the total sum with three decimal places
		  const totalValue = totalSum.toFixed(dec);
	  
		  // Add a row for the total
		//   html += `
		//   <tr class="TOTAL">
		// 	<td class="TOTAL"> ${languageNameSpace.labels['TOTAL']}</td>
		// 	<td class="TOTAL">${totalValue}</td>
		//   </tr>`;
		}
	  }    
	  html += `</table>`; 
	  return `<div>${html}</div>`;
	  
	}
  }


  function getDatasetNameByDefaultSIECAndTrade(fuel, trade) {
	for (const key in codesDataset) {
	  if (codesDataset.hasOwnProperty(key)) {
		const dataset = codesDataset[key];
		if (dataset.fuel.includes(fuel) && dataset.trade.includes(trade) ) {
			datasetobj = {
				name: key,
				unit: dataset.unit,
				defUnit: dataset.defaultUnit,
				defSiec: dataset.defaultSiec,
				siecs: dataset.siec,
			}
		  return datasetobj;
		}
	  }
	}
	return null;
  }


  function getTopFive(array) {
	function sortElements (a, b) {
	  return b[1] - a[1];
	}
	let sortedArray = array.slice().sort(sortElements);
	return sortedArray.slice(0, 5);
  }

  function getKeyByValue(object, targetValue) {
    // Iterate through each key-value pair in the object
    for (const key in object) {
        if (object.hasOwnProperty(key)) {
            // Construct a regular expression to match partial values
            const regex = new RegExp(targetValue, 'i'); // 'i' flag for case-insensitive matching
            // Check if the current value matches the target value partially
            if (regex.test(object[key])) {
                // If found, return the key
                return key;
            }
        }
    }
    // If the target value is not found, return null
    return null;
}


 function euGlobanContainer() {
   const existingContainer = document.getElementById("euGlobanContainer");
   if (existingContainer) {
     existingContainer.remove();
   }

   const euGlobanContainer = document.createElement("div");
   euGlobanContainer.id = "euGlobanContainer";
   
   const header = document.querySelector("header");
   if (header) {
     header.insertBefore(euGlobanContainer, header.firstChild);
   }

   if (window.$wt && window.$wt.render) {
     $wt.render("euGlobanContainer", {
       utility: "globan",
       lang: REF.language.toLowerCase(),
       theme: "dark",
     });
   }
}
 


/**
 * Return chart credits text (language-aware).
 * Keep this function side-effect free so it can be used synchronously
 * when building chart options (Highcharts expects a simple string).
 */
function credits() {
  const safeDataset = encodeURIComponent(REF.dataset || "");
  const safeLang = encodeURIComponent((REF.language || "en").toLowerCase());
  const datasetURL = `https://ec.europa.eu/eurostat/databrowser/view/${safeDataset}/default/table?lang=${safeLang}`;
  const sourceLabel = escapeHTML((languageNameSpace && languageNameSpace.labels && languageNameSpace.labels["EXPORT_FOOTER_TITLE"]) || "Source: Eurostat");
  const accessLabel = escapeHTML((languageNameSpace && languageNameSpace.labels && (languageNameSpace.labels.DB || languageNameSpace.labels["DB_LINK"])) || "Access to dataset");

  // Return SVG-compatible credits text (no DOM access here).
  return `
    <tspan id="credits" style="font-size: 0.9rem;">
      ${sourceLabel} - 
      <tspan
        tabindex="0"
        role="link"
        aria-label="Eurostat dataset link: ${datasetURL}"
        title="${accessLabel}"
        style="cursor: pointer; fill: #0a328e; text-decoration: underline;"
      >
        ${accessLabel}
      </tspan>
    </tspan>
  `;
}

