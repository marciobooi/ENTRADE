class Chart {
    constructor(options) {
      this.containerId = options.containerId;
      this.type = options.type;
      this.title = options.title;
      this.subtitle = options.subtitle;
      this.xAxis = options.xAxis;
      this.yAxisFormat = options.yAxisFormat;
      this.tooltipFormatter = options.tooltipFormatter;
      this.creditsText = options.creditsText;
      this.creditsHref = options.creditsHref;
      this.series = options.series;
      this.colors = options.colors;
      this.legend = options.legend;
      this.columnOptions = options.columnOptions;
      this.pieOptions = options.pieOptions;
      this.seriesOptions = options.seriesOptions;
      this.yAxisTitle = options.yAxisTitle;
    }
  
    createChart() {
      Highcharts.chart(this.containerId, {
        chart: {
          type: this.type,
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          spacingBottom: 50,
          style: {
            fontFamily: 'arial,sans-serif',
            animation: true,
            duration: 1000,
          },
        },
        title: {
          text: this.title,
        },
        subtitle: {
          text: this.subtitle,
        },
        xAxis: this.xAxis,
        yAxis: {
          labels: {
            format: this.yAxisFormat, 
            formatter: function() {
              // Handle zero value separately
              if (this.value === 0) {
                  return '0';
              }

              // Define an array with abbreviated suffixes
              const suffixes = ['k', 'M', 'G', 'T', 'P', 'E'];

              // Get the absolute value of the label
              const value = Math.abs(this.value);

              // Find the appropriate suffix based on the magnitude of the value
              const suffixIndex = Math.floor(Math.log10(value) / 3);

              // Calculate the abbreviated value
              const abbreviatedValue = value / Math.pow(10, suffixIndex * 3);

              // Format the abbreviated value with at most one decimal place
              const formattedValue = abbreviatedValue.toFixed(1).replace(/\.0+$/, '');

              // Return the formatted label with the appropriate suffix
              return formattedValue + suffixes[suffixIndex];
          }
          },
          title: {
            enabled: true,
            text: this.yAxisTitle,            
          },
        },
        colors: this.colors,
        tooltip: {
          formatter: this.tooltipFormatter,
          valueDecimals: 4,
          shared: true,
          useHTML: true,         
          padding: 0,
          // backgroundColor: "rgba(255,255,255,0.9)",   
        },
        credits: {
          text: this.creditsText,
          href: this.creditsHref,
          position:{
            align:'center',
          },   
        },
        legend: this.legend,
        plotOptions: {
          column: this.columnOptions,
          pie: this.pieOptions,
          series: this.seriesOptions,
      },
        series: this.series,
        accessibility: {
          // Use h2 for chart titles in the screen-reader region to preserve
          // a sensible, non-skipping heading order on the page.
          screenReaderSection: {
            beforeChartFormat: '<h2>{chartTitle}</h2><div>{typeDescription}</div><div>{chartSubtitle}</div><div>{chartLongdesc}</div><div>{playAsSoundButton}</div><div>{viewTableButton}</div><div>{xAxisDescription}</div><div>{yAxisDescription}</div><div>{annotationsTitle}{annotationsList}</div>'
          }
        },
        exporting: {      
          enabled: true,
          allowHTML: true,
          sourceWidth: 1200,
          sourceHeight: 850,
          scale: 1,
          chartOptions: {
            subtitle: null,
            credits: "",
            chart: {
              marginTop: 80,
              marginLeft: 80,
              marginRight: 80,
              marginBottom: 100,
              events: {
                load: function () {
                  const chart = this;
                  const logoWidth = 140;
                  const logoHeight = 45;
                  const x = chart.chartWidth - logoWidth - 20;
                  const y = chart.chartHeight - logoHeight - 15;

                  chart.renderer.image(
                    'img/eurostat_logo.png',
                    x,
                    y,
                    logoWidth,
                    logoHeight
                  ).attr({ zIndex: 100 }).add();
                },
                redraw: function () {
                  const chart = this;
                  const images = chart.container.getElementsByTagName('image');
                  if (images.length > 0) {
                    images[0].setAttribute('x', chart.chartWidth - 160);
                    images[0].setAttribute('y', chart.chartHeight - 60);
                  }
                }
              }
            }
          },
                      
          buttons: {
              contextButton: {
                  enabled: false
              }
          }, 
          csv: {
            columnHeaderFormatter: function(item, key) {
                if (!item || item instanceof Highcharts.Axis) {
                  const chartLabels = {
                    "pieChart": languageNameSpace.labels["IND"],
                    "barChart": languageNameSpace.labels["CTR"],
                    "mainChart": languageNameSpace.labels["CTR"],
                    // Add more chart types and their corresponding labels here
                };                    
                // Default label for unknown chart types
                const defaultLabel = languageNameSpace.labels["YEAR"];  
                const label = chartLabels[REF.chartId] || defaultLabel;
                return label;                   
                } else {
                    return item.name;
                }
            }
        }
      }
      }); // end of chart object
      enableScreenREader()
    } // end of chart function
  }

  // function that return empty chart for when is no data to display
  function nullishChart() {
    const chartOptions = {
      containerId: "chartContainer",
      type: null,
      title: null,
      subtitle: null,
      xAxis: null,
      yAxisFormat: null,
      tooltipFormatter: null,
      creditsText: "Source: Eurostat",
      creditsHref: "",
      series: [{ data: [] }],
      colors: null,
      legend: true,
      columnOptions: "",
      seriesOptions: ""
    };
  
    const chart = new Chart(chartOptions);
    chart.createChart();
  }
  

  