if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

async function initApp() {
  await languageNameSpace.initLanguage(REF.language);

  // Initialize GLOBAN after language is set
if (typeof globanManager !== 'undefined') {
  globanManager.init();
}

// Regenerate CCK with the current language
if (typeof cckManager !== 'undefined') {
  cckManager.regenerate(REF.language);
}


  setTimeout(() => {
    document.querySelectorAll("#chartOptionsMenu path").forEach((path) => {
      path.style.fill = "white";
    });
  }, 3000);

  ECL.autoInit();

  // Global default: ensure Highcharts screen-reader chart title uses an H2
  if (typeof Highcharts !== 'undefined' && Highcharts.setOptions) {
    Highcharts.setOptions({
      accessibility: {
        screenReaderSection: {
          beforeChartFormat: '<h2>{chartTitle}</h2><div>{typeDescription}</div><div>{chartSubtitle}</div><div>{chartLongdesc}</div><div>{playAsSoundButton}</div><div>{viewTableButton}</div><div>{xAxisDescription}</div><div>{yAxisDescription}</div><div>{annotationsTitle}{annotationsList}</div>'
        }
      }
    });
  }
}

async function buildComponents() {
  const components = [
    { instance: new SubNavbar(), target: "#subnavbar-container" },
    { instance: new Footer(), target: '#componentFooter' },
    { instance: new Navbar(), target: "#navbar-container" },
  ];

  components.forEach(({ instance, target }) => {
    instance.addToDOM(target);
  });

  await populateDropdownData();
}

function removeComponents() {
  const navbarContainer = document.querySelector("#navbar-container");
  if (navbarContainer) navbarContainer.textContent = '';

  const subnavbarContainer = document.querySelector("#subnavbar-container");
  if (subnavbarContainer) subnavbarContainer.textContent = '';

  const menuSwitch = document.querySelector("#menuSwitch");
  if (menuSwitch) menuSwitch.remove();

  const floatingMenu = document.querySelector("#floatingMenu");
  if (floatingMenu) floatingMenu.textContent = '';

  const componentFooter = document.querySelector("#componentFooter");
  if (componentFooter) componentFooter.textContent = '';
}

async function populateDropdownData() {
  populateTrade();
  populateProduct();
  populateUnit();
  populateFuel();
  await populateYearsData();
  ECL.autoInit();
} 
